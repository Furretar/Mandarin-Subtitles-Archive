import os
from opencc import OpenCC

cc = OpenCC('s2t')  # Traditional to Simplified

for filename in os.listdir('.'):
    if filename.lower().endswith('.srt'):
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
        converted = cc.convert(content)
        out_filename = os.path.splitext(filename)[0] + '.zh-cn.srt'
        with open(out_filename, 'w', encoding='utf-8') as f:
            f.write(converted)
        print(f'Converted: {filename} -> {out_filename}')
